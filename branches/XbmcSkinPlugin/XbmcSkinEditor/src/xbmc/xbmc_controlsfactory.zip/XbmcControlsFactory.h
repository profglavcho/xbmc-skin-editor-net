#ifndef XBMC_CONTROLS_FACTORY
#define XBMC_CONTROLS_FACTORY

#pragma once

#include "lib/StdString.h"

struct _Attributes
{
CStdString name;
CStdString value;
};
typedef std::vector<_Attributes> Attributes;
typedef std::vector<_Attributes>::iterator AttributesIt;
#define XBMC_CONTROLS_COUNT 29

class CXbmcControlsFactory
{
public:
  CXbmcControlsFactory();
	~CXbmcControlsFactory();
  void LoadControls();
  std::vector<CStdString> GetControlsList();
  Attributes GetAttributes(CStdString name);
  void SetAttribute(CStdString name, CStdString value);
protected:
  CStdString m_pCurrent;
  std::vector<Attributes> m_pAllControls;
  Attributes m_pLabel;
  Attributes m_pFadelabel;
  Attributes m_pButton;
  Attributes m_pMultiselect;
  Attributes m_pImage;
  Attributes m_pMultiimage;
  Attributes m_pRadiobutton;
  Attributes m_pSelectbutton;
  Attributes m_pTogglebutton;
  Attributes m_pButtonscrollers;
  Attributes m_pButtonsblock;
  Attributes m_pSpin;
  Attributes m_pSettingsspin;
  Attributes m_pSlider;
  Attributes m_pListcontainer;
  Attributes m_pWraplistcontainer;
  Attributes m_pFixedlistcontainer;
  Attributes m_pPanelcontainer;
  Attributes m_pProgress;
  Attributes m_pTextbox;
  Attributes m_pRssfeed;
  Attributes m_pVisualisation;
  Attributes m_pVideo;
  Attributes m_pMover;
  Attributes m_pResize;
  Attributes m_pEdit;
  Attributes m_pConsole;
  Attributes m_pCheckmark;
  Attributes m_pExtendedlist;
};

#endif