#include "XbmcControlsFactory.h"
#include <algorithm>
#include <vector>

typedef struct
{
  const wchar_t* name;
} XBMC_CONTROL;

static const XBMC_CONTROL control_label[] =
{
  {L"align"},
  {L"aligny"},
  {L"scroll"},
  {L"label"},
  {L"info"},
  {L"number"},
  {L"angle"},
  {L"haspath"},
  {L"font"},
  {L"textcolor"},
  {L"shadowcolor"},
  {L"wrapmultiline"},
  {L"scrollspeed"},
  {L"scrollsuffix"}
};
static const XBMC_CONTROL control_fadelabel[] =
{
  {L"scroll"},
  {L"scrollout"},
  {L"pauseatend"},
  {L"label"},
  //"info" ---> List(Of String)
  {L"font"},
  {L"textcolor"},
  {L"textoffsetx"}
};
static const XBMC_CONTROL control_button[] =
{
  {L"texturefocus"},
  {L"texturenofocus"},
  {L"label"},
  {L"font"},
  {L"textcolor"},
  {L"disabledcolor"},
  {L"align"},
  {L"aligny"},
  {L"textoffsetx"},
  {L"textoffsety"},
  {L"onclick"},
  {L"onfocus"}
};

static const XBMC_CONTROL control_multiselect[] =
{
  {L"texturefocus"},
  {L"texturenofocus"},
  {L"label"},
  {L"font"},
  {L"textcolor"},
  {L"disabledcolor"},
  {L"aligny"},
  {L"textoffsetx"},
  {L"textoffsety"},
};

static const XBMC_CONTROL control_image[] =
{
  {L"fadetime"},
  {L"bordersize"},
  {L"info"},
  {L"aspectratio"},
  // texture border="5" flipy="true" flipx="false"","")
  // bordertexture border="5"","")
};
static const XBMC_CONTROL control_multiimage[] =
{
  {L"imagepath"},
  {L"info"},
  {L"timeperimage"},
  {L"fadetime"},
  {L"pauseatend"},
  {L"randomize"},
  {L"aspectratio"},
};

static const XBMC_CONTROL control_radiobutton[] =
{
  {L"texturefocus"},
  {L"texturenofocus"},
  {L"textureradioon"},
  {L"textureradiooff"},
  {L"selected"},
  {L"onclick"},
  {L"label"},
  {L"font"},
  {L"textcolor"},
  {L"disabledcolor"},
  {L"align"},
  {L"aligny"},
  {L"textoffsetx"},
  {L"textoffsety"},
};

static const XBMC_CONTROL control_selectbutton[] =
{
  {L"texturefocus"},
  {L"texturenofocus"},
  {L"texturebg"},
  {L"textureleft"},
  {L"textureleftfocus"},
  {L"textureright"},
  {L"texturerightfocus"},
  {L"label"},
  {L"font"},
  {L"textcolor"},
  {L"disabledcolor"},
  {L"align"},
  {L"alignY"},
  {L"textoffsetx"},
  {L"textoffsety"},
};

static const XBMC_CONTROL control_togglebutton[] =
{
  {L"texturefocus"},
  {L"texturenofocus"},
  {L"alttexturefocus"},
  {L"alttexturenofocus"},
  {L"usealttexture"},
  {L"label"},
  {L"altlabel"},
  {L"font"},
  {L"textcolor"},
  {L"disabledcolor"},
  {L"align"},
  {L"aligny"},
  {L"textoffsetx"},
  {L"textoffsety"},
  {L"onclick"},
  {L"onfocus"},
};

static const XBMC_CONTROL control_buttonscrollers[] =
{
  {L"texturefocus"},
  {L"texturenofocus"},
  {L"font"},
  {L"textcolor"},
  {L"align"},
  {L"aligny"},
  {L"textoffsetx"},
  {L"textoffsety"},
  {L"numbuttons"},
  {L"buttongap"},
  {L"orientation"},
  {L"defaultbutton"},
  {L"movement"},
  {L"alpha"},
  {L"wraparound"},
  {L"smoothscrolling"},
};

CXbmcControlsFactory::CXbmcControlsFactory()
{
  LoadControls();
}

CXbmcControlsFactory::~CXbmcControlsFactory()
{
}

_Attributes BuildAttribute(CStdStringW name, CStdStringW value)
{
  _Attributes att;
  att.name = name;
  att.value = value;
  return att;
}

bool mypredicate (_Attributes i, _Attributes j)
{
  if(i.name.Equals(j.name))
    return true;
  else
    return false;
  
}

void CXbmcControlsFactory::SetAttribute(CStdString name, CStdString value)
{
  AttributesIt it;
  int i;
  for (i = 0; i <m_pAllControls.size(); i++)
  {
    Attributes search;
    search.push_back(BuildAttribute(m_pCurrent,L""));
    //find the control holding this
    it = std::search (m_pAllControls[i].begin(),m_pAllControls[i].end(),search.begin(), search.end(),mypredicate);
    if ( it != m_pAllControls[i].end())
      break;
  }
  if (it == m_pAllControls[i].end())
  {
    //not supposed to happen
    assert(0);
    return;
  }
  for (AttributesIt itt = m_pAllControls[i].begin(); itt != m_pAllControls[i].end(); it++)
  {
    if (itt->name.Equals(name))
    {
      itt->value = value;
      break;
    }
  }
  
  
  //m_pCurrent
}

Attributes CXbmcControlsFactory::GetAttributes(CStdString name)
{
  m_pCurrent = name;
  if (name.Equals(L"label"))
    return m_pLabel;
    else if(name.Equals(L"fadelabel"))    return m_pFadelabel;
  else if(name.Equals(L"button"))    return m_pButton;
  else if(name.Equals(L"multiselect"))    return m_pMultiselect;
  else if(name.Equals(L"image"))    return m_pImage;
  else if(name.Equals(L"multiimage"))    return m_pMultiimage;
  else if(name.Equals(L"radiobutton"))    return m_pRadiobutton;
  else if(name.Equals(L"selectbutton"))    return m_pSelectbutton;
  else if(name.Equals(L"togglebutton"))    return m_pTogglebutton;
  else if(name.Equals(L"buttonscrollers"))    return m_pButtonscrollers;
  else if(name.Equals(L"buttonsblock"))    return m_pButtonsblock;
  else if(name.Equals(L"spin"))    return m_pSpin;
  else if(name.Equals(L"settingsspin"))    return m_pSettingsspin;
  else if(name.Equals(L"slider"))    return m_pSlider;
  else if(name.Equals(L"listcontainer"))    return m_pListcontainer;
  else if(name.Equals(L"wraplistcontainer"))    return m_pWraplistcontainer;
  else if(name.Equals(L"fixedlistcontainer"))    return m_pFixedlistcontainer;
  else if(name.Equals(L"panelcontainer"))    return m_pPanelcontainer;
  else if(name.Equals(L"progress"))    return m_pProgress;
  else if(name.Equals(L"textbox"))    return m_pTextbox;
  else if(name.Equals(L"rssfeed"))    return m_pRssfeed;
  else if(name.Equals(L"visualisation"))    return m_pVisualisation;
  else if(name.Equals(L"video"))    return m_pVideo;
  else if(name.Equals(L"mover"))    return m_pMover;
  else if(name.Equals(L"resize"))    return m_pResize;
  else if(name.Equals(L"edit"))    return m_pEdit;
  else if(name.Equals(L"console"))    return m_pConsole;
  else if(name.Equals(L"checkmark"))    return m_pCheckmark;
  else if(name.Equals(L"extendedlist"))    return m_pExtendedlist;
  else
  {
    Attributes nothing;
    return nothing;
  }
}
std::vector<CStdString> CXbmcControlsFactory::GetControlsList()
{
  std::vector<CStdString> list;
  list.push_back(L"label");
  list.push_back(L"fadelabel");
  list.push_back(L"button");
  list.push_back(L"multiselect");
  list.push_back(L"image");
  list.push_back(L"multiimage");
  list.push_back(L"radiobutton");
  list.push_back(L"selectbutton");
  list.push_back(L"togglebutton");
  list.push_back(L"buttonscrollers");
  list.push_back(L"buttonsblock");
  list.push_back(L"spin");
  list.push_back(L"settingsspin");
  list.push_back(L"slider");
  list.push_back(L"listcontainer");
  list.push_back(L"wraplistcontainer");
  list.push_back(L"fixedlistcontainer");
  list.push_back(L"panelcontainer");
  list.push_back(L"progress");
  list.push_back(L"textbox");
  list.push_back(L"rssfeed");
  list.push_back(L"visualisation");
  list.push_back(L"video");
  list.push_back(L"mover");
  list.push_back(L"resize");
  list.push_back(L"edit");
  list.push_back(L"console");
  list.push_back(L"checkmark");
  list.push_back(L"extendedlist");
  return list;

}

Attributes GetDefaultAttributes()
{
  Attributes input;
  input.push_back(BuildAttribute(L"type",L""));
  input.push_back(BuildAttribute(L"description",L""));
  input.push_back(BuildAttribute(L"id",L""));
  input.push_back(BuildAttribute(L"posx",L""));
  input.push_back(BuildAttribute(L"posy",L""));
  input.push_back(BuildAttribute(L"width",L""));
  input.push_back(BuildAttribute(L"height",L""));
  input.push_back(BuildAttribute(L"visible",L""));
  input.push_back(BuildAttribute(L"animation",L""));
  input.push_back(BuildAttribute(L"camera",L""));
  input.push_back(BuildAttribute(L"colordiffuse",L""));
  input.push_back(BuildAttribute(L"onup",L""));
  input.push_back(BuildAttribute(L"ondown",L""));
  input.push_back(BuildAttribute(L"onleft",L""));
  input.push_back(BuildAttribute(L"onright",L""));
  input.push_back(BuildAttribute(L"hitrect",L""));
  input.push_back(BuildAttribute(L"enable",L""));
  input.push_back(BuildAttribute(L"pulseonselect",L""));
  return input;
}

void CXbmcControlsFactory::LoadControls()
{
  m_pLabel = GetDefaultAttributes();
  unsigned int i = 0;
  for ( i = 0; i < sizeof(control_label)/sizeof(XBMC_CONTROL); i++)
    m_pLabel.push_back(BuildAttribute(control_label[i].name,L""));
  m_pFadelabel= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_fadelabel)/sizeof(XBMC_CONTROL); i++)
    m_pFadelabel.push_back(BuildAttribute(control_fadelabel[i].name,L""));
  m_pButton= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_button)/sizeof(XBMC_CONTROL); i++)
    m_pButton.push_back(BuildAttribute(control_button[i].name,L""));
  m_pMultiselect= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_multiselect)/sizeof(XBMC_CONTROL); i++)
    m_pMultiselect.push_back(BuildAttribute(control_multiselect[i].name,L""));
  m_pImage= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_image)/sizeof(XBMC_CONTROL); i++)
    m_pImage.push_back(BuildAttribute(control_image[i].name,L""));
  m_pMultiimage= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_multiimage)/sizeof(XBMC_CONTROL); i++)
    m_pMultiimage.push_back(BuildAttribute(control_multiimage[i].name,L""));
  m_pRadiobutton= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_radiobutton)/sizeof(XBMC_CONTROL); i++)
    m_pRadiobutton.push_back(BuildAttribute(control_radiobutton[i].name,L""));
  m_pSelectbutton= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_selectbutton)/sizeof(XBMC_CONTROL); i++)
    m_pSelectbutton.push_back(BuildAttribute(control_selectbutton[i].name,L""));
  m_pTogglebutton= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_togglebutton)/sizeof(XBMC_CONTROL); i++)
    m_pTogglebutton.push_back(BuildAttribute(control_togglebutton[i].name,L""));
  m_pButtonscrollers= GetDefaultAttributes();
  for ( i = 0; i < sizeof(control_buttonscrollers)/sizeof(XBMC_CONTROL); i++)
    m_pButtonscrollers.push_back(BuildAttribute(control_buttonscrollers[i].name,L""));
  m_pButtonsblock= GetDefaultAttributes();
  m_pSpin= GetDefaultAttributes();
  m_pSettingsspin= GetDefaultAttributes();
  m_pSlider= GetDefaultAttributes();
  m_pListcontainer= GetDefaultAttributes();
  m_pWraplistcontainer= GetDefaultAttributes();
  m_pFixedlistcontainer= GetDefaultAttributes();
  m_pPanelcontainer= GetDefaultAttributes();
  m_pProgress= GetDefaultAttributes();
  m_pTextbox= GetDefaultAttributes();
  m_pRssfeed= GetDefaultAttributes();
  m_pVisualisation= GetDefaultAttributes();
  m_pVideo= GetDefaultAttributes();
  m_pMover= GetDefaultAttributes();
  m_pResize= GetDefaultAttributes();
  m_pEdit= GetDefaultAttributes();
  m_pConsole= GetDefaultAttributes();
  m_pCheckmark= GetDefaultAttributes();
  m_pExtendedlist= GetDefaultAttributes();
  //put them in a single vector for easy search
  m_pAllControls.push_back(m_pLabel);
  m_pAllControls.push_back(m_pFadelabel);
  m_pAllControls.push_back(m_pButton);
  m_pAllControls.push_back(m_pMultiselect);
  m_pAllControls.push_back(m_pImage);
  m_pAllControls.push_back(m_pMultiimage);
  m_pAllControls.push_back(m_pRadiobutton);
  m_pAllControls.push_back(m_pSelectbutton);
  m_pAllControls.push_back(m_pTogglebutton);
  m_pAllControls.push_back(m_pButtonscrollers);
  m_pAllControls.push_back(m_pButtonsblock);
  m_pAllControls.push_back(m_pSpin);
  m_pAllControls.push_back(m_pSettingsspin);
  m_pAllControls.push_back(m_pSlider);
  m_pAllControls.push_back(m_pListcontainer);
  m_pAllControls.push_back(m_pWraplistcontainer);
  m_pAllControls.push_back(m_pFixedlistcontainer);
  m_pAllControls.push_back(m_pPanelcontainer);
  m_pAllControls.push_back(m_pProgress);
  m_pAllControls.push_back(m_pTextbox);
  m_pAllControls.push_back(m_pRssfeed);
  m_pAllControls.push_back(m_pVisualisation);
  m_pAllControls.push_back(m_pVideo);
  m_pAllControls.push_back(m_pMover);
  m_pAllControls.push_back(m_pResize);
  m_pAllControls.push_back(m_pEdit);
  m_pAllControls.push_back(m_pConsole);
  m_pAllControls.push_back(m_pCheckmark);
  m_pAllControls.push_back(m_pExtendedlist);

}
