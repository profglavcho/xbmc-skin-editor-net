/*
This file is part of MultiClipboard Plugin for Notepad++
Copyright (C) 2009 LoonyChewy

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef XBMC_IMAGE_PREVIEWER_H
#define XBMC_IMAGE_PREVIEWER_H

#ifndef UNITY_BUILD_SINGLE_INCLUDE
#include "resource.h"
#include "PictureCtrl.h"
#include "ModelViewController.h"
#endif

// ID for dockable window
#define	MULTICLIPBOARD_DOCKABLE_WINDOW_INDEX 0


class XbmcImagePreviewer : public CDialog,
                           public IController
{
public:
	XbmcImagePreviewer(CWnd* pParent = NULL);
	~XbmcImagePreviewer();

  


	enum { IDD = IDD_DOCK_IMAGE_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
  //CWinthread
public:
  CPictureCtrl m_picCtrl;
  BOOL Create();

protected:
  CWnd* m_pParent;
	int m_nID;
  LRESULT ScintillaMsg(UINT message, WPARAM wParam = 0, LPARAM lParam = 0);
  void ScintillaSearch(char *text, int start, int end);
  void ScintillaGetText(char *text, int start, int end);
  virtual BOOL OnInitDialog();
  afx_msg HRESULT OnNcHitTest(CPoint point);
  DECLARE_MESSAGE_MAP()
private:

  std::wstring m_pCurrentFile;

	void ShowImage();
	

	virtual void OnObserverAdded( LoonySettingsManager * SettingsManager );
	virtual void OnSettingsChanged( const stringType & GroupName, const stringType & SettingName );
};


#endif