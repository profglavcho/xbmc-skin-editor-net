/*
This file is part of MultiClipboard Plugin for Notepad++
Copyright (C) 2009 LoonyChewy

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef UNITY_BUILD_SINGLE_INCLUDE
#include "XbmcImagePreviewer.h"
#include "NativeLang_def.h"
#include "MultiClipboardSettings.h"
#include "MultiClipboardSettingsDialog.h"
#include "xbmc/lib/xbmc_communicator.h"
#endif


//************************ define here your toolbar layout *********************

extern HINSTANCE g_hInstance;
extern NppData g_NppData;
extern MultiClipboardSettingsDialog OptionsDlg;
extern HWND	g_HSource;

XbmcImagePreviewer::XbmcImagePreviewer(CWnd* pParent)
: CDialog(XbmcImagePreviewer::IDD, pParent)
{
  m_pParent = pParent;
	m_nID = XbmcImagePreviewer::IDD;
}


XbmcImagePreviewer::~XbmcImagePreviewer()
{
}

void XbmcImagePreviewer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_PICTURE, m_picCtrl);
}

BOOL XbmcImagePreviewer::OnInitDialog()
{
	CDialog::OnInitDialog();

	

	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

BOOL XbmcImagePreviewer::Create()
{
  return CDialog::Create(m_nID, m_pParent);
}

#if 0
BOOL CALLBACK XbmcImagePreviewer::run_dlgProc( HWND hWnd, UINT msg, WPARAM wp, LPARAM lp )
{

	switch ( msg )
	{
	case WM_INITDIALOG:
		InitialiseDialog();
		break;
  case WM_NCHITTEST:
    ShowImage();
    break;
	case WM_SIZE:
	case WM_MOVE:
		{
			RECT rc;
			getClientRect(rc);
			break;
		}

	case WM_NOTIFY:
		{
			LPNMHDR nmhdr = (LPNMHDR) lp;
			if ( nmhdr->hwndFrom == _hParent )
			{
				switch ( LOWORD( nmhdr->code ) )
				{
				case DMN_FLOAT:
				case DMN_DOCK:
					{
						if ( LOWORD( nmhdr->code ) == DMN_FLOAT )
						{
							_isFloating = true;
						}
						else
						{
							_isFloating = false;
							_iDockedPos = HIWORD( nmhdr->code );
						}
						break;
					}
				default:
					// Parse all other notifications to docking dialog interface
					return DockingDlgInterface::run_dlgProc( _hSelf, msg, wp, lp );
				}
			}
			else
			{
				// Parse all other notifications to docking dialog interface
				return DockingDlgInterface::run_dlgProc( _hSelf, msg, wp, lp );
			}
			break;
		}

	case WM_DESTROY:
		// Destroy icon of tab
		::DestroyIcon( TBData.hIconTab );
		break;

	default:
		return DockingDlgInterface::run_dlgProc( _hSelf, msg, wp, lp );
	}

	return FALSE;
}
#endif

BEGIN_MESSAGE_MAP(XbmcImagePreviewer, CDialog)
	ON_WM_NCHITTEST()
END_MESSAGE_MAP()

HRESULT XbmcImagePreviewer::OnNcHitTest(CPoint point)
{
	ShowImage();
  return S_OK;
}

void XbmcImagePreviewer::ShowImage()
{
  
  TCHAR currentmsg[MAX_PATH];
  int current_line = ::SendMessage(g_NppData._nppHandle, NPPM_GETCURRENTLINE , 0,0);//MAX_PATH, (LPARAM)currentmsg);
  std::wstring strCurrentLine = currentmsg;
  INT line_start = (INT)ScintillaMsg(SCI_POSITIONFROMLINE, current_line);
	INT line_end = (INT)ScintillaMsg(SCI_GETLINEENDPOSITION, current_line);
  int buffer_size = line_end-line_start+1;
  LPSTR strLine = (LPSTR) new CHAR[buffer_size];

  ScintillaGetText(strLine, line_start,line_end);

  ScintillaMsg(SCI_SETSEARCHFLAGS, SCFIND_REGEXP|SCFIND_POSIX);
  ScintillaMsg(SCI_SETTARGETSTART, line_start);
  ScintillaMsg(SCI_SETTARGETEND, line_end);
  const char *regex = ">(.+?)<";

  std::string strLineStripped;

  int posFound = ScintillaMsg(SCI_SEARCHINTARGET, strlen(regex), (LPARAM)regex);
  if (posFound>-1)
  {
    int imagestart,imageend;
    imagestart = ScintillaMsg(SCI_GETTARGETSTART);
    imageend = ScintillaMsg(SCI_GETTARGETEND);
    LPSTR image_str = (LPSTR) new CHAR[imageend-imagestart+1];
    ScintillaGetText(strLine, imagestart,imageend);
    strLineStripped = strLine;
    strLineStripped.erase(0,1);
    
    strLineStripped.pop_back();
    
  }
  

}

void XbmcImagePreviewer::ScintillaGetText(char *text, int start, int end) 
{
	TextRange tr;
	tr.chrg.cpMin = start;
	tr.chrg.cpMax = end;
	tr.lpstrText  = text;
	ScintillaMsg(SCI_GETTEXTRANGE, 0, reinterpret_cast<LPARAM>(&tr));
  
}
void XbmcImagePreviewer::ScintillaSearch(char *text, int start, int end) 
{
	TextRange tr;
	tr.chrg.cpMin = start;
	tr.chrg.cpMax = end;
	tr.lpstrText  = text;
	ScintillaMsg(SCI_GETTEXTRANGE, 0, reinterpret_cast<LPARAM>(&tr));
  
}

/***
 *	ScintillaMsg()
 *
 *	API-Wrapper
 */
LRESULT XbmcImagePreviewer::ScintillaMsg(UINT message, WPARAM wParam, LPARAM lParam)
{
	return ::SendMessage(g_HSource, message, wParam, lParam);
}

void XbmcImagePreviewer::OnObserverAdded( LoonySettingsManager * SettingsManager )
{
	SettingsObserver::OnObserverAdded( SettingsManager );
}


void XbmcImagePreviewer::OnSettingsChanged( const stringType & GroupName, const stringType & SettingName )
{
	if ( GroupName != SETTINGS_GROUP_XBMC )
		return;
}